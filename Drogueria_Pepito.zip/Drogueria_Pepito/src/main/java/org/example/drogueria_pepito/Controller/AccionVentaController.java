package org.example.drogueria_pepito.Controller;


import org.example.drogueria_pepito.HelloApplication;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.ObservableList;
import org.example.drogueria_pepito.*;

import java.time.LocalDate;
/*Este es el controlador del vista accion venta
* falta hacer la conexion a la base d edatospara poder elegir un producto, no funcion bien*/
public class AccionVentaController {

    @FXML
    private ComboBox<Producto> productoComboBox;
    @FXML
    private TextField cantidadTextField;
    @FXML
    private ComboBox<Usuario> usuarioComboBox;
    @FXML
    private TableView<DetalleVenta> detalleVentaTable;
    @FXML
    private TableColumn<DetalleVenta, String> productoColumn;
    @FXML
    private TableColumn<DetalleVenta, Integer> cantidadColumn;

    private Venta.Builder ventaBuilder = new Venta.Builder();
    private ObservableList<DetalleVenta> detallesVenta = FXCollections.observableArrayList();

    @FXML
    public void initialize() throws Exception {
        // Configurar las columnas de la tabla
        productoColumn.setCellValueFactory(new PropertyValueFactory<>("productoNombre"));
        cantidadColumn.setCellValueFactory(new PropertyValueFactory<>("cantidad"));

        // Configurar la tabla con una lista observable
        detalleVentaTable.setItems(detallesVenta);

        // Cargar los productos y usuarios en los ComboBox
        cargarProductos();
        cargarUsuarios();
    }

    @FXML
    private void agregarDetalleVenta() {
        Producto producto = productoComboBox.getValue();
        int cantidad = Integer.parseInt(cantidadTextField.getText());
        Usuario usuario = new Usuario("Juan", "ardillaenllamas");
        DetalleVenta detalleVenta = new DetalleVenta(producto,usuario, cantidad);
        detallesVenta.add(detalleVenta);
        detalleVentaTable.getItems().add(detalleVenta);
    }

    @FXML
    private void crearVenta() {
        Usuario usuario = usuarioComboBox.getValue();
        ventaBuilder.setUsuario(usuario);

        // Aquí se considera un solo detalle de venta, para varios detalles se debe modificar la lógica
        detallesVenta.forEach(ventaBuilder::setDetalleVenta);

        Venta venta = ventaBuilder.build();

        // Aquí puedes realizar las acciones necesarias para guardar la venta o procesarla
        System.out.println("Venta creada con éxito: " + venta.getPrecioCompra());
    }

    private void cargarProductos() {
        // Ejemplo de productos, deberías cargar estos desde tu base de datos o fuente de datos
        Producto producto1 = new Producto("001", "Producto A", "Marca A", 10.0f, LocalDate.of(2024, 12, 31), 50);
        Producto producto2 = new Producto("002", "Producto B", "Marca B", 20.0f, LocalDate.of(2025, 6, 30), 30);

        productoComboBox.setItems(FXCollections.observableArrayList(producto1, producto2));
    }

    private void cargarUsuarios() throws Exception{ //siempre que sea para cambiar de ventana añadan esto de throws Exception
        // Ejemplo de usuarios, deberías cargar estos desde tu base de datos o fuente de datos
        Usuario usuario1 = new Usuario("Juan Perez", "001");
        Usuario usuario2 = new Usuario("Ana Gomez", "002");

        usuarioComboBox.setItems(FXCollections.observableArrayList(usuario1, usuario2));

        HelloApplication.setRoot("hello-view.fxml");
    }
}