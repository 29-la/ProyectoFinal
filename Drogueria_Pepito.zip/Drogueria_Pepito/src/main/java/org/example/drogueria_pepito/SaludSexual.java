package org.example.drogueria_pepito;

public class SaludSexual {
    private String nombre;

    public SaludSexual(String nombre) {
        this.nombre = nombre;

    }
    public String getNombre() {
        return nombre;
    }
}