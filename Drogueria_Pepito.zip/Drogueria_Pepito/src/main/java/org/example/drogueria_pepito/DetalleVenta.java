package org.example.drogueria_pepito;


public class DetalleVenta implements Cloneable{
    private Producto producto;
    private Usuario usuario;
    private int cantidad;

    public DetalleVenta(Producto producto, Usuario usuario, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.usuario = usuario;
    }
    public Usuario getUsuario() {
        return usuario;

    }
    public Producto getProducto() {

        return producto;
    }
    public int getCantidad() {

        return cantidad;
    }
    @Override
    public DetalleVenta clone() {
        try {
            DetalleVenta cloned = (DetalleVenta) super.clone();
            cloned.producto = producto.clone(); // Clonación profunda del producto
            cloned.usuario = usuario.clone();   // Clonación profunda del usuario
            return cloned;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("DetalleVenta{");
        sb.append("producto=").append(producto);
        sb.append(", usuario=").append(usuario);
        sb.append(", cantidad=").append(cantidad);
        sb.append('}');
        return sb.toString();
    }
}
