package org.example.drogueria_pepito;

public interface ValidarEmpleado {
    boolean esEmpleado(String codigo);
}
