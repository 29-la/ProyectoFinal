package org.example.drogueria_pepito.command;


import org.example.drogueria_pepito.DetalleVenta;
import org.example.drogueria_pepito.Venta;

//clase concrete que implementa command

public class DetalleVentaCommand implements Command {
    private Venta venta;
    private DetalleVenta detalleVenta;

    public DetalleVentaCommand(Venta venta, DetalleVenta detalleVenta) {
        this.venta = venta;
        this.detalleVenta = detalleVenta;
    }


    @Override
    public void execute() {
        venta.addDetalleVenta(detalleVenta);
    }


    @Override
    public void undo() {
        venta.removeDetalleVenta(detalleVenta);
    }

}
