package org.example.drogueria_pepito;


public class IngresarProxy implements ValidarEmpleado {

    public IngresarProxy(Empleado empleado) {
    }
//valida que el codigo ingresado por el user empiece por 1092
    @Override
    public boolean esEmpleado(String codigo) {
        return codigo.startsWith("1092");
    }
}