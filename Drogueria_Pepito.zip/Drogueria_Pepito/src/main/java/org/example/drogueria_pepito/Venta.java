package org.example.drogueria_pepito;


import java.util.ArrayList;
import java.util.List;

public class Venta implements DevolucionHandler {
    private float precioCompra;
    private DetalleVenta detalleVenta;
    private Usuario usuario;
    private DevolucionHandler next;
    private List<DetalleVenta> detallesVenta = new ArrayList<>();

    public Venta(float precioTotal, DetalleVenta detalleVenta, Usuario usuario) {
        this.precioCompra = calcularPrecioCompra(detalleVenta);
        this.detalleVenta = detalleVenta;
        this.usuario = usuario;
    }



    public static class Builder {
        private DetalleVenta detalleVenta;
        private Usuario usuario;

        public Builder setDetalleVenta(DetalleVenta detalleVenta) {
            this.detalleVenta = detalleVenta;
            return this;
        }

        public Builder setUsuario(Usuario usuario) {
            this.usuario = usuario;
            return this;
        }

        public Venta build() {
            if (detalleVenta == null || usuario == null) {
                throw new IllegalArgumentException("La venta y el usuario son obligatorios.");
            }
            return new Venta(calcularPrecioCompra(detalleVenta), detalleVenta, usuario);
        }

        private float calcularPrecioCompra(DetalleVenta detalleVenta) {
            if (detalleVenta == null || detalleVenta.getProducto() == null) {
                throw new NullPointerException("La detalle del venta o producto no puede ser nulo.");
            }
            float precioProducto = detalleVenta.getProducto().getPrecio();
            int cantidad = detalleVenta.getCantidad();
            return precioProducto * cantidad;
        }
    }

    @Override
    public DevolucionHandler getHandler() {
        return next;
    }

    @Override
    public void setHandler(DevolucionHandler handler) {
        next = handler;
    }

    @Override
    public int handleDevolucion(float precioCompra) {
        if (next != null) {
            return next.handleDevolucion(precioCompra);
        }
        return 0;
    }
    public float calcularPrecioCompra(DetalleVenta detalleVenta) {
        if (detalleVenta == null || detalleVenta.getProducto() == null) {
            throw new NullPointerException("El detalle de venta o el producto es nulo");
        }
        float precioProducto = detalleVenta.getProducto().getPrecio();
        int cantidad = detalleVenta.getCantidad();
        return precioProducto * cantidad;
    }
    public float getPrecioCompra() {
        return precioCompra;
    }

    public DetalleVenta getDetalleVenta() {
        return this.detalleVenta;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public double calcularPrecioConDescuento(EstrategiaDescuento estrategiaDescuento) {
        if (detalleVenta.getCantidad() >= 3) {
            return estrategiaDescuento.calcularPrecio(precioCompra);
        }
        return precioCompra;
    }
    public void addDetalleVenta(DetalleVenta detalleVenta) {
        detallesVenta.add(detalleVenta);
        System.out.println("Detalle de venta agregado: " + detalleVenta.getProducto().getNombre() + " - Cantidad: " + detalleVenta.getCantidad());
    }
    public void removeDetalleVenta(DetalleVenta detalleVenta) {
        detallesVenta.remove(detalleVenta);
        System.out.println("Detalle de venta eliminado: " + detalleVenta.getProducto().getNombre() + " - Cantidad: " + detalleVenta.getCantidad());
    }
    public List<DetalleVenta> getDetallesVenta() {
        return detallesVenta;
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Venta{");
        sb.append("precioCompra=").append(precioCompra);
        sb.append(", detalleVenta=").append(detalleVenta);
        sb.append(", usuario=").append(usuario);
        sb.append(", detallesVenta=").append(detallesVenta);
        sb.append('}');
        return sb.toString();
    }
}

