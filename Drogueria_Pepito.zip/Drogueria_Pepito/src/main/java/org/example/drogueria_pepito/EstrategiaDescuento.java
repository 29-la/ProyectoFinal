package org.example.drogueria_pepito;

//se crea una estrategia de descuento para el precio compra
public class EstrategiaDescuento implements DescuentoStrategy {
    private double porcentajeDescuento;

    public EstrategiaDescuento(double porcentajeDescuento) {
        this.porcentajeDescuento = porcentajeDescuento;
    }

    @Override
    public double calcularPrecio(double precio) {
        return precio - (precio * porcentajeDescuento / 100);
    }
}
