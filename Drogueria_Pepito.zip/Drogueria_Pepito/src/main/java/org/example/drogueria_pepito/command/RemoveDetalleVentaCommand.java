package org.example.drogueria_pepito.command;

import org.example.drogueria_pepito.DetalleVenta;
import org.example.drogueria_pepito.Venta;
// clase concreta para remover el detalle
public class RemoveDetalleVentaCommand implements Command {
    private Venta venta;
    private DetalleVenta detalleVenta;

    public RemoveDetalleVentaCommand(Venta venta, DetalleVenta detalleVenta) {
        this.venta = venta;
        this.detalleVenta = detalleVenta;
    }


    @Override
    public void execute() {
        venta.removeDetalleVenta(detalleVenta);
    }

    @Override
    public void undo() {
        venta.addDetalleVenta(detalleVenta);
    }

    {
    }
}
