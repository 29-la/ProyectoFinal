/*
* Aplicacion creada por Laura Valentina Gomez Alzate, David Gomez Ramirez y Nicolas Muñoz Viveros
* Aplicacion de sistema de una farmacia
* fecha 27 de mayo del 2024*/

package org.example.drogueria_pepito;

import org.example.drogueria_pepito.command.Command;
import org.example.drogueria_pepito.command.DetalleVentaCommand;
import org.example.drogueria_pepito.command.Invoker;
import org.example.drogueria_pepito.command.RemoveDetalleVentaCommand;

import java.time.LocalDate;




public class Main {
    public static void main(String[] args) {
        // Crear productos

            // Crear usuario
            Usuario usuario = new Usuario("Juan", "juan@example.com");

            // Crear producto
            Producto producto1 = new Producto("111", "Paracetamol", "dd", 5000,LocalDate.now(),7);
            Producto producto2 = new Producto("112", "Paracetamol", "Genérico", 500000, LocalDate.now(), 100);
            // Crear detalle de venta
            DetalleVenta detalleVenta = new DetalleVenta(producto1, usuario,3);

            // Crear venta
            Venta venta = new Venta.Builder()
                    .setDetalleVenta(detalleVenta)
                    .setUsuario(usuario)
                    .build();

            // Agregar detalle de venta
            DetalleVenta detalleVenta2 = new DetalleVenta(new Producto("222", "Ibuprofeno", "genfar", 3000, LocalDate.now(),2),usuario,2);
            venta.addDetalleVenta(detalleVenta2);


        // Crear inventario y agregar productos
        Stock stock = new Stock();
        stock.crear(producto1);
        stock.crear(producto2);

        // Leer y actualizar producto en el inventario
        Producto p = stock.leer("112");
        if (p != null) {
            System.out.println("Producto encontrado: " + p.getNombre());
        }
        stock.actualizar("112", new Producto("112", "Paracetamol", "Genérico", 450000, LocalDate.now(), 100));
        Producto updatedProduct = stock.leer("112");
        if (updatedProduct != null) {
            System.out.println("Producto actualizado: " + updatedProduct.getNombre() + ", precio: " + updatedProduct.getPrecio());
        }

        // Eliminar producto del inventario
        stock.eliminar("111");
        Producto deletedProduct = stock.leer("111");
        if (deletedProduct == null) {
            System.out.println("Producto eliminado correctamente.");
        }

        // Crear usuario
        Usuario usuario2 = new Usuario("Juan", "ardillaenllamas");

        DetalleVenta detalleVenta1 = new DetalleVenta(producto1, usuario,3);
        // Crear venta
        Venta venta1 = new Venta( 300,detalleVenta1,usuario);

        // Crear detalle de venta


        // Crear comandos
        Command addDetalleCommand = new DetalleVentaCommand(venta, detalleVenta1);
        Command removeDetalleCommand = new RemoveDetalleVentaCommand(venta, detalleVenta1);

        // Crear invoker
        Invoker invoker = new Invoker();

        // Ejecutar comandos
        invoker.executeCommand(addDetalleCommand);  // Agregar el detalle de venta
        System.out.println("Detalle agregado: Producto - " + detalleVenta1.getProducto().getNombre() + ", Cantidad - " + detalleVenta1.getCantidad());

        invoker.undoCommand();  // Deshacer la acción, eliminando el detalle de venta
        System.out.println("Detalle eliminado mediante undo: Producto - " + detalleVenta1.getProducto().getNombre() + ", Cantidad - " + detalleVenta1.getCantidad());

        invoker.executeCommand(removeDetalleCommand);  // Eliminar el detalle de venta
        invoker.undoCommand();  // Deshacer la acción, agregando el detalle de venta de nuevo

        // Mostrar detalles de venta restantes
        System.out.println("Detalles de venta actuales:");
        for (DetalleVenta detalle : venta.getDetallesVenta()) {
            System.out.println("Producto: " + detalle.getProducto().getNombre() + ", Cantidad: " + detalle.getCantidad());
        }


    // Crear estrategias de descuento
    DescuentoStrategy descuentoPorcentaje = new EstrategiaDescuento(10); // Descuento del 10%
    DescuentoStrategy precioNormal = new EstrategiaPrecioNormal(); // Precio normal sin descuento

    // Calcular precios con diferentes estrategias
    double precioConDescuento = descuentoPorcentaje.calcularPrecio(100);
    double precioSinDescuento = precioNormal.calcularPrecio(100);

    System.out.println("Precio con descuento del 10%: " + precioConDescuento);
    System.out.println("Precio sin descuento: " + precioSinDescuento);

        Drogueria drogueria1 = Drogueria.getDrogueria();
        Drogueria drogueria2 = Drogueria.getDrogueria();

        // Verificar si las dos instancias son la misma
        if (drogueria1 == drogueria2) {
            System.out.println("Ambas instancias son la misma");
        } else {
            System.out.println("Ambas instancias no son la misma");
        }
        Producto producto = new Producto("11","acetaminofen","generico", 10520,LocalDate.now(),2);

        // Agregar producto a la drogueria
        drogueria1.agregarProducto(producto);

        // Crear instancia de Venta
        Venta venta2 = new Venta(1000,detalleVenta, usuario);

        // Agregar venta a la drogueria
        drogueria1.agregarVenta(venta2);

        // Imprimir productos y ventas
        System.out.println("Productos: " + drogueria1.getProductos());
        System.out.println("Ventas: " + drogueria1.getVentas());

}}
