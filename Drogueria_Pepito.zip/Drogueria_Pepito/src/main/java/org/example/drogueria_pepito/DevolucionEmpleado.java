package org.example.drogueria_pepito;


    public class DevolucionEmpleado implements DevolucionHandler {
        private DevolucionHandler next;
//clase que implementa la interfaz de devolucion y hace la logica para una devolucion hecha por empleado
        @Override
        public DevolucionHandler getHandler() {
            return next;
        }

        @Override
        public int handleDevolucion(float precioCompra) {
            if (precioCompra <= 500000) {
                System.out.println("Devolución hecha por el empleado");
                return 1; // Indica que el empleado realizó la devolución
            } else if (next != null) {
                System.out.println("pasala");
            }
            return next.handleDevolucion(precioCompra);

        }

        @Override
        public void setHandler(DevolucionHandler handler) {
            next = handler;
        }
    }



