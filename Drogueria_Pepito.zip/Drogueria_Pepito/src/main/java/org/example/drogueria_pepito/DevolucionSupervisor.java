package org.example.drogueria_pepito;


    public class DevolucionSupervisor implements DevolucionHandler {
        private DevolucionHandler next;
        //clase que implementa la interfaz de devolucion y hace la logica para una devolucion hecha por empleado
        @Override
        public DevolucionHandler getHandler() {
            return next;
        }

        @Override
        public int handleDevolucion(float precioCompra) {
            if (precioCompra > 500000) {
                System.out.println("Devolución hecha por el supervisor");
                return 2; // Indica que el supervisor realizó la devolución
            } else if (next != null) {
                System.out.println("pasala");
                return next.handleDevolucion(precioCompra);
            }
            return 0 ; // Indica que no se pudo manejar la devolución
        }

        @Override
        public void setHandler(DevolucionHandler handler) {
            next = handler;
        }
    }

