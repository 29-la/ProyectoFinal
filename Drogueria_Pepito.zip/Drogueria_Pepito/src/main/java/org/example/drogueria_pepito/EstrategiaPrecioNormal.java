package org.example.drogueria_pepito;

public class EstrategiaPrecioNormal implements DescuentoStrategy {
    @Override
    public double calcularPrecio(double precio) {
        return precio;
    }
}
