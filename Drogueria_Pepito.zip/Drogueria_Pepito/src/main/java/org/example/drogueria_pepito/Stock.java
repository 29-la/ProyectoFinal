package org.example.drogueria_pepito;

import java.util.ArrayList;
import java.util.List;

//clase stock que implementa los metodos para hacer transacciones crud
    public class Stock implements Crud<Producto> {
        private List<Producto> productos;

        public Stock() {
            productos = new ArrayList<>();
        }



        public Producto buscarProducto(String nombreProducto) {
            for (Producto producto : productos) {
                if (producto.getNombre().equals(nombreProducto)) {
                    return producto;
                }
            }
            return null;
        }
//metodo para agregar un poducto a una lista
        @Override
        public void crear(Producto producto) {
            productos.add(producto);
        }
//metodo para leer la lista de productos
        @Override
        public Producto leer(String codigo) {
            for (Producto producto : productos) {
                if (producto.getCodigo().equals(codigo)) {
                    return producto;
                }
            }
            return null;
        }

        @Override
        public void actualizar(String codigo, Producto producto) {
            Producto productoToUpdate = leer(codigo);
            if (productoToUpdate != null) {
                productoToUpdate.setNombre(producto.getNombre());
                productoToUpdate.setPrecio(producto.getPrecio());
                productoToUpdate.setCantidad(producto.getCantidad());
            }
        }

        @Override
        public void eliminar(String codigo) {
            Producto productoToDelete = leer(codigo);
            if (productoToDelete != null) {
                productos.remove(productoToDelete);
            }
        }
    }