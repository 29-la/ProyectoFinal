package org.example.drogueria_pepito;
//clase ususrio, es el cliente de al farmacia

public class Usuario implements Cloneable{
    private String nombre;
    private String id;
    public Usuario(String nombre, String id) {
        this.nombre = nombre;
        this.id = id;
    }
    public String getNombre(){
        return nombre;
    }
    @Override
    public Usuario clone() {
        try {
            return (Usuario) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new AssertionError();
        }
    }
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Usuario{");
        sb.append("nombre='").append(nombre).append('\'');
        sb.append(", id='").append(id).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
