package org.example.drogueria_pepito.command;

//interface command contiene los metodos de excute y undo

public interface Command {
    void execute();
    void undo();
}