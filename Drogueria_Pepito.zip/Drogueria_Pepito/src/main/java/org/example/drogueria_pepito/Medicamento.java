package org.example.drogueria_pepito;

public class Medicamento {

    private String nombre;

    public Medicamento(String nombre) {

        this.nombre = nombre;

    }
    public String getNombre() {
        return nombre;
    }
}

