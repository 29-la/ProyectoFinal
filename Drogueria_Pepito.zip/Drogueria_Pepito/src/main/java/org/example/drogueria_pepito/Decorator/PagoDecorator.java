package org.example.drogueria_pepito.Decorator;


public abstract class PagoDecorator implements MetodoPago{
    protected MetodoPago metodoPagoDecorado;

    public PagoDecorator(MetodoPago metodoPagoDecorado) {
        this.metodoPagoDecorado = metodoPagoDecorado;
    }

    @Override
    public void procesarPago(double monto) {
        metodoPagoDecorado.procesarPago(monto);
    }
}
