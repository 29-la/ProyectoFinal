package org.example.drogueria_pepito.Controller;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import org.example.drogueria_pepito.Empleado;
import org.example.drogueria_pepito.HelloApplication;
import org.example.drogueria_pepito.IngresarProxy;
/*en este controlador estan las cciones para que pueda iniciar sesion en la aplicacion
* se pide el nombre y el codigo, deb ingresar un condigo que empiece por1092 d elo contrario no puede loggearse. s ehace uso del patron proxy*/
public class LoginController {

    @FXML
    private TextField usuarioField;

    @FXML
    private TextField codigoField;

    @FXML
    private Label mensajeLabel;

    private IngresarProxy ingresarProxy;

    @FXML
    void initialize() {
    }

    @FXML
    void handleLogin() throws Exception {
        String usuario = usuarioField.getText();
        String codigo = codigoField.getText();

        Empleado empleado = new Empleado(usuario,codigo);
        ingresarProxy = new IngresarProxy(empleado);
        if (ingresarProxy.esEmpleado(empleado.getCodigo())) {
            // Iniciar sesión correctamente
            mensajeLabel.setText("Bienvenido, " + usuario);
            HelloApplication.setRoot("AccionVenta.fxml"); //Aqui cambiar la ruta a la de venta

        } else {
            mensajeLabel.setText("Código incorrecto");
        }
    }
}

