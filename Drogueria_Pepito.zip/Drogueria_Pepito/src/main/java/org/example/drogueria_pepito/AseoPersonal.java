package org.example.drogueria_pepito;

//clase concreta que se agrega una lista de productos

public class AseoPersonal {
    private String nombre;

    public AseoPersonal(String nombre) {
        this.nombre = nombre;

    }

    public String getNombre() {
        return nombre;
    }
}
