package org.example.drogueria_pepito.Decorator;

import org.example.drogueria_pepito.DescuentoStrategy;
//uso del patron decorator para aplicar otro descuento en strategy
public class DescuentoDecorator extends PagoDecorator{
    private DescuentoStrategy descuentoStrategy;

    public DescuentoDecorator(MetodoPago metodoPagoDecorado, DescuentoStrategy descuentoStrategy) {
        super(metodoPagoDecorado);
        this.descuentoStrategy = descuentoStrategy;
    }

    @Override
    public void procesarPago(double monto) {
        double montoConDescuento = descuentoStrategy.calcularPrecio(monto);
        super.procesarPago(montoConDescuento);
    }
}
