package org.example.drogueria_pepito;

public interface DescuentoStrategy {
    double calcularPrecio(double precio);
}
