package org.example.drogueria_pepito.Controller;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import org.example.drogueria_pepito.*;

import java.time.LocalDate;
/*Esta clase seencarga de controlar el vista de un devolucion, se aplica el patron chain of responsability para validar quien puede hacer la transaccion*/
public class VentaController {

    @FXML
    private Label mensajeLabel;

    private Producto producto1;
    private Producto producto2;
    private Usuario usuario;
    private Venta venta;
    private DevolucionEmpleado devolucionEmpleado;
    private DevolucionSupervisor devolucionSupervisor;

    @FXML
    private Label productoLabel;

    @FXML
    private Label cantidadLabel;

    @FXML
    private Label usuarioLabel;

    @FXML
    private TextField precioCompraField;
//se inicializan las clases necesarias
    public VentaController() {
        devolucionEmpleado = new DevolucionEmpleado();
        devolucionSupervisor = new DevolucionSupervisor();
        Producto producto1 = new Producto("112", "Paracetamol", "Genérico", 500000, LocalDate.now(), 100);
        Usuario usuario = new Usuario ("valentina","1092");
        DetalleVenta detalleVenta = new DetalleVenta(producto1,usuario,3);
        venta = new Venta(500000,detalleVenta,usuario); // Inicializar la variable venta
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
        productoLabel.setText("Producto: " + venta.getDetalleVenta().getProducto().getNombre());
        cantidadLabel.setText("Cantidad: " + venta.getDetalleVenta().getCantidad());
        usuarioLabel.setText("Usuario: " + venta.getUsuario().getNombre());
    }

    public void mostrarMensaje(String mensaje) {
        Platform.runLater(() -> {
            mensajeLabel.setText(mensaje);
        });
    }
//se hace la validacion del manejador de la devolucion
    @FXML
    void handleDevolucion() {
        System.out.println("handleDevolucion: Iniciando proceso de devolución.");

        // Obtener el precio de compra ingresado por el usuario
        String precioCompraText = precioCompraField.getText();

        try {
            float precioCompra = Float.parseFloat(precioCompraText);

            // Realizar devoluciones para diferentes casos
            int resultado = realizarDevolucion(precioCompra);

            String mensajeEmpleado;
            String mensajeSupervisor;

            if (resultado == 1) {
                mensajeSupervisor = "";
                mensajeEmpleado = "La devolución la realiza el empleado.";
            } else if (resultado == 2) {
                mensajeEmpleado = "";
                mensajeSupervisor = "La devolución la realiza el supervisor. ";
            } else {
                mensajeEmpleado = "";
                mensajeSupervisor = "";
            }

            Platform.runLater(() -> {
                mensajeLabel.setText(mensajeEmpleado + "\n" + mensajeSupervisor);
            });
        } catch (NumberFormatException e) {
            Platform.runLater(() -> {
                mensajeLabel.setText("Error: El precio de compra debe ser un número.");
            });
        }
    }

    private int realizarDevolucion(float precioCompra) {
        System.out.println("realizarDevolucion: Iniciando devolución con precio de compra: " + precioCompra);

        venta.setHandler(devolucionEmpleado);

        devolucionEmpleado.setHandler(devolucionSupervisor);

        int resultado = venta.handleDevolucion(precioCompra);
        System.out.println("realizarDevolucion: Resultado de la devolución: " + resultado);

        return resultado;
    }
}
