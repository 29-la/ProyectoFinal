package org.example.drogueria_pepito;

import java.util.ArrayList;
import java.util.List;
// clase principal drogueria
public class Drogueria {
    private static Drogueria instance;
    private final List<Venta> ventas;
    private List<Producto> productos;

    private Drogueria() {
        this.ventas = new ArrayList<>();
        this.productos = new ArrayList<>();
    }
//constructor del singleton
    public static Drogueria getDrogueria (){
        if (instance == null){
            instance = new Drogueria();
        }
        return instance;
    }

    public void agregarVenta(Venta venta) {
        ventas.add(venta);
    }

    public void agregarProducto(Producto producto) {
        productos.add(producto);
    }



    public List<Venta> getVentas() {
        return ventas;
    }


    public List<Producto> getProductos() {
        return productos;
    }
}
