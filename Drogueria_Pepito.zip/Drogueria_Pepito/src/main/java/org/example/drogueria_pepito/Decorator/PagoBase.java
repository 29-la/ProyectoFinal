package org.example.drogueria_pepito.Decorator;

public class PagoBase implements MetodoPago{
    @Override
    public void procesarPago(double monto) {
        //System.out.println("Procesando pago de: " + monto);
        //Aquí no se como se haría para conectarlo con la interfaz gráfica
    }
}
