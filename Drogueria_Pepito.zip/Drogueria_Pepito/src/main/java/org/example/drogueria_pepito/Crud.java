package org.example.drogueria_pepito;

public interface Crud<T> {
    void crear(T objeto);
    T leer(String codigo);
    void actualizar(String codigo, T objeto);
    void eliminar(String codigo);
}
