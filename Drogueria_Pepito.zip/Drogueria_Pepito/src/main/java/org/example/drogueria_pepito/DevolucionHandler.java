package org.example.drogueria_pepito;

public interface DevolucionHandler {
    void setHandler (DevolucionHandler handler);

    public DevolucionHandler getHandler();

    int handleDevolucion(float precioCompra);



}
