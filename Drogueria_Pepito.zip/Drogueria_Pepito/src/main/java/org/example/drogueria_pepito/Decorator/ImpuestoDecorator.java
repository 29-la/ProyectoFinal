package org.example.drogueria_pepito.Decorator;



public class ImpuestoDecorator extends PagoDecorator{
    private double porcentajeImpuesto;

    public ImpuestoDecorator(MetodoPago metodoPagoDecorado, double porcentajeImpuesto) {
        super(metodoPagoDecorado);
        this.porcentajeImpuesto = porcentajeImpuesto;
    }

    @Override
    public void procesarPago(double monto) {
        double montoConImpuesto = monto + (monto * porcentajeImpuesto / 100);
        //System.out.println("Al aplicar impuesto de " + porcentajeImpuesto + "%, el monto total es: " + montoConImpuesto);
        //Para revisar para aplicar con la interfaz gráfica
        super.procesarPago(montoConImpuesto);
    }
}
