package org.example.drogueria_pepito.Decorator;

public interface MetodoPago {
    void procesarPago(double monto);
}
