
module org.example.drogueria_pepito {
    requires javafx.fxml;
    requires javafx.controls;
    exports org.example.drogueria_pepito;
    opens org.example.drogueria_pepito.Controller to javafx.fxml;
}